from helper import LED

led = LED(r=15, g=13, b=12)

led.blink()
